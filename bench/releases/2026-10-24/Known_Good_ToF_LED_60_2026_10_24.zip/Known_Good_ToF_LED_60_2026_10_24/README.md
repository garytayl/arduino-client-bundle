# Known-good combined ToF + LED bench

This is the exact source backed up from the first combined version uploaded and serial-verified on 2026-10-24. It includes the Pololu VL53L1X on main Wire, FastLED D6/WS2812B/GRB, 60 provisional LEDs, brightness 16, a four-second intro, and one presence-triggered flowing glow per approach.

The original upload wrote 65,400 binary bytes over 16 pages. Live serial confirmed sensor_ok=1, valid distances, an ENTER event at 55 mm, and rearming after a clear reading around 2434 mm. Thresholds are enter below 800 mm and clear above 950 mm, with persistence and stale-data handling.

The .ino is unchanged from backups/ToF_LED_Presence_Bench_v1.uploaded-before-readable-logs.ino. verified-upload.bin is the exact binary retained from that build. SHA256SUMS.txt records both hashes. Preserve these files; make future variants in separate directories.

The readable-log variant is separate and was not uploaded by this agent. This known-good version uses numeric serial status lines and EVENT ENTER messages. A stream of pixel=N color_pass=N belongs to the LED-only bench and is not this sensor sketch.

Physical LED count and appearance are not established by compilation or serial logs. 60 remains an approximate configured count.
