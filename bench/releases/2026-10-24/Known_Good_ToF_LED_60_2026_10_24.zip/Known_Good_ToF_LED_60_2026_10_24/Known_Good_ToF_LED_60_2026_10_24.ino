/* ToF_LED_Presence_Bench_v1 — compile-tested bench, not physically validated.
   UNO R4 WiFi; FastLED D6 WS2812B/GRB; 60 pixels (provisional count); brightness 16/255.
   Pololu VL53L1X on main Wire (SDA/SCL), default address 0x29.
   Preserve existing sensor supply wiring; do not infer supply from this code.
   One sensor detects presence, NOT travel direction. No D2/D3 inputs.
   Provisional thresholds for reported ~1045 mm background:
   first establish clear >950 mm for >=400 ms / >=5 valid samples;
   then <800 mm for >=200 ms / >=3 valid samples triggers one flowing glow.
   Staying near cannot retrigger. Clear must be confirmed to rearm.
   Invalid/zero/I2C-error results reset debounce, never mean near or clear.
   >1000 ms without valid data disarms; confirmed clear required after recovery.
   Existing presence latch is retained during stale/invalid data.
   A 4-second intro runs once; presence glow lasts 3.5 seconds.
   Both use a narrow soft trail at brightness16, not a full-strip white fill.
   LED count is provisional: change NUM_LEDS after physical count is established.
   No delay or blocking ranging in loop; each I2C transfer and show is synchronous.
   Init failure leaves LEDs off until reset. Serial 115200 logs events + 500ms status.
   Coordinate sensor wiring readiness and exact upload before flashing.
*/
#include <Arduino.h>
#include <Wire.h>
#include <FastLED.h>
#include <VL53L1X.h>
#if !defined(ARDUINO_UNOR4_WIFI)
#error "Select Arduino UNO R4 WiFi."
#endif

// BEGIN_PORTABLE_GATE
struct PresenceGate {
  static constexpr uint16_t ENTER_MM = 800, EXIT_MM = 950;
  static constexpr uint32_t STALE_MS = 1000;
  bool armed = false, present = false, fresh = false, haveValid = false;
  uint32_t lastValid = 0, candidateSince = 0;
  uint8_t candidate = 0, samples = 0; // 1=near, 2=clear
  void resetCandidate() { candidate = 0; samples = 0; }
  void tick(uint32_t now) {
    if (haveValid && uint32_t(now - lastValid) > 180) resetCandidate();
    if (!haveValid || uint32_t(now - lastValid) > STALE_MS) {
      fresh = false;
      armed = false;
      resetCandidate();
    }
  }
  bool update(uint32_t now, bool valid, uint16_t mm) {
    tick(now);
    if (!valid || mm == 0) { resetCandidate(); return false; }
    haveValid = true; fresh = true; lastValid = now;
    const uint8_t zone = mm < ENTER_MM ? 1 : (mm > EXIT_MM ? 2 : 0);
    if (!zone) { resetCandidate(); return false; }
    if (zone != candidate) { candidate = zone; candidateSince = now; samples = 0; }
    if (samples < 255) ++samples;
    const uint32_t elapsed = uint32_t(now - candidateSince);
    if (zone == 2 && samples >= 5 && elapsed >= 400) {
      present = false; armed = true;
    }
    if (zone == 1 && samples >= 3 && elapsed >= 200 && armed && !present) {
      present = true; armed = false; resetCandidate(); return true;
    }
    return false;
  }
};
// END_PORTABLE_GATE

constexpr uint8_t LED_PIN = 6, BRIGHTNESS = 16;
constexpr uint16_t NUM_LEDS = 60; // approximate physical count, not verified
constexpr uint32_t POLL_MS = 10, FRAME_MS = 25, REPORT_MS = 500;
CRGB leds[NUM_LEDS];
VL53L1X sensor;
PresenceGate gate;
bool sensorOK = false, animating = false, intro = true, lastSampleValid = false;
uint16_t lastMm = 0;
uint8_t lastRangeStatus = 255;
uint32_t lastPoll = 0, lastReport = 0, animationStart = 0;
uint32_t lastFrame = 0;

void startSweep(uint32_t now) {
  animationStart = now; animating = true; intro = false;
  Serial.println("EVENT ENTER: one flowing glow");
}
void animate(uint32_t now) {
  if (!intro && !animating) return;
  if (uint32_t(now - lastFrame) < FRAME_MS) return;
  lastFrame = now;
  const uint32_t elapsed = uint32_t(now - animationStart);
  const uint32_t duration = intro ? 4000 : 3500;
  if (elapsed >= duration) {
    FastLED.clear(true); animating = false; intro = false; return;
  }
  // Subpixel head and a soft eight-pixel tail keep motion fluid and load modest.
  const float progress = float(elapsed) / float(duration);
  const float head = progress * (NUM_LEDS + 10.0f);
  fill_solid(leds, NUM_LEDS, CRGB::Black);
  for (uint16_t i = 0; i < NUM_LEDS; ++i) {
    const float distance = head - float(i);
    if (distance < -1.0f || distance > 8.0f) continue;
    const float envelope = distance < 0 ? 1.0f + distance : 1.0f - distance / 8.0f;
    const uint8_t level = uint8_t(255.0f * envelope * envelope);
    const uint8_t hue = (intro ? 155 : 135) + uint8_t(i / 2) + uint8_t(elapsed / 100);
    leds[i] = CHSV(hue, 230, level);
  }
  FastLED.show();
}
void setup() {
  Serial.begin(115200);
  FastLED.addLeds<WS2812B, LED_PIN, GRB>(leds, NUM_LEDS);
  FastLED.setBrightness(BRIGHTNESS); FastLED.setDither(0); FastLED.clear(true);
  Serial.println("# TOF_LED_PRESENCE_BENCH_V1 | D6 | 60 provisional | brightness16 | Wire | 115200");
  animationStart = millis();
  Wire.begin(); Wire.setClock(400000); Wire.setWireTimeout(25000, true);
  sensor.setTimeout(100);
  if (!sensor.init() || !sensor.setDistanceMode(VL53L1X::Long) ||
      !sensor.setMeasurementTimingBudget(50000)) {
    Serial.println("FAULT sensor initialization failed; LEDs off; reset after checking sensor");
    intro = false;
    return;
  }
  sensor.startContinuous(60);
  animationStart = millis();
  sensorOK = sensor.last_status == 0;
  if (!sensorOK) intro = false;
  Serial.println(sensorOK ? "READY: establish clear >950mm before approach <800mm" :
                           "FAULT starting ranging; LEDs off");
}
void loop() {
  const uint32_t now = millis();
  gate.tick(now);
  if (sensorOK && uint32_t(now - lastPoll) >= POLL_MS) {
    lastPoll = now;
    const bool ready = sensor.dataReady();
    if (sensor.last_status != 0) {
      lastSampleValid = false; gate.update(now, false, 0);
    } else if (ready) {
      const uint16_t mm = sensor.read(false);
      lastRangeStatus = uint8_t(sensor.ranging_data.range_status);
      const bool timedOut = sensor.timeoutOccurred();
      lastSampleValid = sensor.last_status == 0 && !timedOut &&
        sensor.ranging_data.range_status == VL53L1X::RangeValid && mm > 0;
      if (lastSampleValid) lastMm = mm;
      if (gate.update(now, lastSampleValid, mm)) startSweep(now);
    }
  }
  animate(now);
  if (uint32_t(now - lastReport) >= REPORT_MS) {
    lastReport = now;
    Serial.print("mm=");
    if (gate.haveValid) Serial.print(lastMm); else Serial.print("NA");
    Serial.print(" sample_valid="); Serial.print(lastSampleValid);
    Serial.print(" range_status="); Serial.print(lastRangeStatus);
    Serial.print(" fresh="); Serial.print(gate.fresh);
    Serial.print(" armed="); Serial.print(gate.armed);
    Serial.print(" present="); Serial.print(gate.present);
    Serial.print(" sensor_ok="); Serial.println(sensorOK);
  }
}
